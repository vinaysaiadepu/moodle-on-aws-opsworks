log "stuff"

resource "doit"
